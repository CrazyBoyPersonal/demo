CREATE VIEW view_sal_em AS
  SELECT
    `companysales`.`employee`.`EmployeeName`              AS `姓名`,
    (`companysales`.`employee`.`Salary` * 0.1)            AS `奖金`,
    ((`companysales`.`employee`.`Salary` - 800) * 0.15)   AS `所得税`,
    ((`companysales`.`employee`.`Salary` + (`companysales`.`employee`.`Salary` * 0.1)) -
     ((`companysales`.`employee`.`Salary` - 800) * 0.15)) AS `实发工资`
  FROM `companysales`.`employee`;
