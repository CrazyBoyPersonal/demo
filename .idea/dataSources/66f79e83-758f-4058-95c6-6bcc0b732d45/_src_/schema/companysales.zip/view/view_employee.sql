CREATE VIEW view_employee AS
  SELECT
    `companysales`.`employee`.`EmployeeID`       AS `EmployeeID`,
    `companysales`.`employee`.`EmployeeName`     AS `EmployeeName`,
    `companysales`.`employee`.`Sex`              AS `Sex`,
    `companysales`.`employee`.`BirthDate`        AS `BirthDate`,
    `companysales`.`employee`.`HireDate`         AS `HireDate`,
    `companysales`.`employee`.`Salary`           AS `Salary`,
    `companysales`.`employee`.`DepartmentID`     AS `DepartmentID`,
    `companysales`.`department`.`DepartmentName` AS `DepartmentName`
  FROM (`companysales`.`employee`
    JOIN `companysales`.`department`
      ON ((`companysales`.`employee`.`DepartmentID` = `companysales`.`department`.`DepartmentID`)));
