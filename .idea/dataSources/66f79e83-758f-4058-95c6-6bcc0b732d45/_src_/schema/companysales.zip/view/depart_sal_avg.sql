CREATE VIEW depart_sal_avg AS
  SELECT
    `companysales`.`view_employee`.`DepartmentName` AS `DepartmentName`,
    avg(`companysales`.`view_employee`.`Salary`)    AS `avg(``Salary``)`
  FROM `companysales`.`view_employee`
  GROUP BY `companysales`.`view_employee`.`DepartmentName`;
